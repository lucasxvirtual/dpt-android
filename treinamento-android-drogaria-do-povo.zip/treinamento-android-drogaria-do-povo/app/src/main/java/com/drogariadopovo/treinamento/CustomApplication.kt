package com.drogariadopovo.treinamento

import android.support.multidex.MultiDexApplication
import com.drogariadopovo.treinamento.api.ConsultApi

class CustomApplication : MultiDexApplication() {

    var consultApi : ConsultApi? = null

    companion object {
        private var _instance : CustomApplication? = null

        fun getInstance() : CustomApplication {
            return _instance!!
        }
    }

    override fun onCreate() {
        super.onCreate()

        if(_instance == null){
            _instance = this
        }

        consultApi = ConsultApi(getString(R.string.base_url))
    }

}