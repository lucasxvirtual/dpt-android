package com.drogariadopovo.treinamento.activity.login

import android.os.Bundle
import com.drogariadopovo.treinamento.activity.MainActivity
import com.drogariadopovo.treinamento.R
import com.drogariadopovo.treinamento.activity.BaseActivity
import kotlinx.android.synthetic.main.activity_login.*
import org.jetbrains.anko.startActivity

class LoginActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        supportActionBar?.hide()

        cpf.text.insert(0,"123456789")
        name_birth.text.insert(0,"321@123")

        enter.setOnClickListener {
            var login = cpf.text.toString()
            var password = name_birth.text.toString()

            if(login == "123456789" && password == "321@123")
                this.startActivity<MainActivity>()
            else {
                cpf.error = "CPF Inválido"
                name_birth.error = "Informação Inválida"
            }

        }

    }
}