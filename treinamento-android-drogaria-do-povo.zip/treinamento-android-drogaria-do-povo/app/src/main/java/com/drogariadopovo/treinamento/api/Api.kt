package com.drogariadopovo.treinamento.api

import retrofit2.Response

open class Api {
    interface ApiCallback<T> {
        fun onResponse(t: T)

        fun onConnectionFailure(t: Throwable)

        fun onFailure(error: Response<T>)
    }
}