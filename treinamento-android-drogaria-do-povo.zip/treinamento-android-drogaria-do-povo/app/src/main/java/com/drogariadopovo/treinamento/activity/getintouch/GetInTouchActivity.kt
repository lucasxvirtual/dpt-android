package com.drogariadopovo.treinamento.activity.getintouch

import android.os.Bundle
import android.view.MenuItem
import com.drogariadopovo.treinamento.R
import com.drogariadopovo.treinamento.activity.BaseActivity
import kotlinx.android.synthetic.main.fragment_getintouchwith_hr.*
import org.jetbrains.anko.toast

class GetInTouchActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.fragment_getintouchwith_hr)

        supportActionBar?.title = "Contatar RH"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        view_radioButton.setOnClickListener {
            if(!contact_anonymously.isChecked)
                contact_anonymously.isChecked = true
            else
                contact_anonymously_group.clearCheck()
        }

        send.setOnClickListener {
            toast(contact_anonymously.isChecked.toString())
        }

    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        onBackPressed()
        return super.onOptionsItemSelected(item)
    }
}