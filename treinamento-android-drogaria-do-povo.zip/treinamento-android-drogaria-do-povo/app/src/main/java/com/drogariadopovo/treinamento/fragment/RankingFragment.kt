package com.drogariadopovo.treinamento.fragment

import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.content.ContextCompat
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import br.com.guiadeacessibilidade.util.ViewHolder
import com.drogariadopovo.treinamento.R
import com.drogariadopovo.treinamento.util.GenericRecyclerAdapter
import kotlinx.android.synthetic.main.fragment_ranking.*
import kotlinx.android.synthetic.main.fragment_ranking.view.*
import kotlinx.android.synthetic.main.item_store.view.*

class RankingFragment : Fragment() {

    private var list = listOf("1","2","3","4","5")
    private var recycler : RecyclerView? = null
    private var isStore = true

    override fun onResume() {
        super.onResume()
            setAdapterStore(list)
        if(isStore){
            onStoreClicked()
        } else {
            onNetClicked()
        }
    }

    fun onStoreClicked(){
        view?.store_text?.setTextColor(ContextCompat.getColor(view!!.context,R.color.white))
        view?.store?.backgroundTintList = ContextCompat.getColorStateList(view!!.context, R.color.blue)

        view?.net_text?.setTextColor(ContextCompat.getColor(view!!.context,R.color.blue))
        view?.net?.backgroundTintList = ContextCompat.getColorStateList(view!!.context, R.color.white)
        isStore = true
        setAdapterStore(list)
    }

    fun onNetClicked(){
        view?.store_text?.setTextColor(ContextCompat.getColor(view!!.context, R.color.blue))
        view?.store?.backgroundTintList = ContextCompat.getColorStateList(view!!.context, R.color.white)

        view?.net_text?.setTextColor(ContextCompat.getColor(view!!.context, R.color.white))
        view?.net?.backgroundTintList = ContextCompat.getColorStateList(view!!.context, R.color.blue)
        isStore = false
        setAdapterStore(list)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_ranking, container, false)

        recycler = view.findViewById(R.id.recycler_store_net)
        recycler!!.layoutManager = LinearLayoutManager(context)

        view.store.setOnClickListener {
            onStoreClicked()
        }

        view.net.setOnClickListener {
            onNetClicked()
        }
        return view
    }

    fun setAdapterStore(list : List<String>){
        recycler_store_net?.adapter = GenericRecyclerAdapter<String, ViewHolder>(context, list, object : GenericRecyclerAdapter.GenericRecyclerViewInterface<String, ViewHolder>{
            override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): ViewHolder {
                return ViewHolder(layoutInflater.inflate(R.layout.item_store, parent, false))
            }

            override fun onBindViewHolder(holder: ViewHolder?, position: Int, list: List<String>?) {
                val view = holder!!.itemView
                if(!isStore){
                    view.name.text = "Matriz"
            }
                view.ranking_number.text = list!![position]
            }
        })
    }
}