package com.drogariadopovo.treinamento.fragment

import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import br.com.guiadeacessibilidade.util.ViewHolder
import com.drogariadopovo.treinamento.R
import com.drogariadopovo.treinamento.activity.QuizActivity
import com.drogariadopovo.treinamento.util.GenericRecyclerAdapter
import kotlinx.android.synthetic.main.item_activity.view.*
import org.jetbrains.anko.startActivity

class ActivitiesFragment : Fragment() {

    private var recycler : RecyclerView? = null
    private var list = listOf("1","2","3","4","5","6")

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_activity, container, false)

        recycler = view.findViewById(R.id.recycler)

        recycler = view.findViewById(R.id.recycler)
        recycler!!.layoutManager = LinearLayoutManager(context)

        return view
    }

    override fun onResume() {
        super.onResume()
        setAdapter(list)
    }

    fun setAdapter(list : List<String>){
        recycler?.adapter = GenericRecyclerAdapter<String, ViewHolder>(context, list, object : GenericRecyclerAdapter.GenericRecyclerViewInterface<String, ViewHolder>{
            override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): ViewHolder {
                return ViewHolder(layoutInflater.inflate(R.layout.item_activity, parent, false))
            }

            override fun onBindViewHolder(holder: ViewHolder?, position: Int, list: List<String>?) {
                val view = holder!!.itemView

                view.quiz_button.setOnClickListener {
                    activity!!.startActivity<QuizActivity>()

                }

            }
        })
    }
}