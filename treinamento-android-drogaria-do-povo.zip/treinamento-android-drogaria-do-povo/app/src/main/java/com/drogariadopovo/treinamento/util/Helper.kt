package br.com.guiadeacessibilidade.util

import android.content.Context
import android.net.ConnectivityManager

class Helper {
    companion object {
        fun isConnected(context: Context) : Boolean{
            val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val activeNetworkInfo = connectivityManager.activeNetworkInfo
            return activeNetworkInfo != null && activeNetworkInfo.isConnected
        }

        fun getStates() : ArrayList<String>{
            return arrayListOf("Rio de Janeiro", "São Paulo")
        }
    }
}