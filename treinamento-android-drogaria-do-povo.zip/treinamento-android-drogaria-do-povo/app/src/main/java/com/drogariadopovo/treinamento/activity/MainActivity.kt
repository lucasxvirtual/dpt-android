package com.drogariadopovo.treinamento.activity

import android.content.Intent
import android.os.Bundle
import android.support.design.widget.BottomNavigationView
import android.support.v4.app.Fragment
import android.view.Menu
import android.view.MenuItem
import br.com.guiadeacessibilidade.util.SharedPreferencesHelper
import com.drogariadopovo.treinamento.R
import com.drogariadopovo.treinamento.activity.login.LoginActivity
import com.drogariadopovo.treinamento.fragment.ActivitiesFragment
import com.drogariadopovo.treinamento.fragment.AwardsFragment
import com.drogariadopovo.treinamento.fragment.ProfileFragment
import com.drogariadopovo.treinamento.fragment.RankingFragment
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : BaseActivity() {

    private var isProfile = false
    val fragment1 = ActivitiesFragment()
    val fragment2 = AwardsFragment()
    val fragment3 = RankingFragment()
    val fragment4 = ProfileFragment()

    private val mOnNavigationItemSelectedListener = BottomNavigationView.OnNavigationItemSelectedListener { item ->
        when (item.itemId) {
            R.id.activity -> {
                addFragment(fragment1)
                supportActionBar?.title = "Atividade"
                invalidateOptionsMenu()
                isProfile = false
                return@OnNavigationItemSelectedListener true
            }
            R.id.awards -> {
                addFragment(fragment2)
                supportActionBar?.title = "Premiações"
                invalidateOptionsMenu()
                isProfile = false
                return@OnNavigationItemSelectedListener true
            }
            R.id.ranking -> {
                addFragment(fragment3)
                supportActionBar?.title = "Ranking"
                invalidateOptionsMenu()
                isProfile = false
                return@OnNavigationItemSelectedListener true
            }
            R.id.profile -> {
                addFragment(fragment4)
                supportActionBar?.title = "Perfil"
                invalidateOptionsMenu()
                isProfile = true
                return@OnNavigationItemSelectedListener true
            }
        }
        false
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        if (isProfile)
            menuInflater.inflate(R.menu.menu, menu)
        return super.onCreateOptionsMenu(menu)
    }

    private fun addFragment(fragment: Fragment) {
        supportFragmentManager
                .beginTransaction()
                .replace(R.id.frame, fragment, fragment.javaClass.simpleName)
                .commit()
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        if (item?.itemId!! == R.id.exit) {
            val sp = SharedPreferencesHelper(this)
            sp.erase()
            val intent = Intent(this, LoginActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        }

        return super.onOptionsItemSelected(item)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener)
        navigation.isSaveEnabled = false

        val fragment1 = ActivitiesFragment()
        supportActionBar?.title = "Atividade"
        addFragment(fragment1)

    }
}