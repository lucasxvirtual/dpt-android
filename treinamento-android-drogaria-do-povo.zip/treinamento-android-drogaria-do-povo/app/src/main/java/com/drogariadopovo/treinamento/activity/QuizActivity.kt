package com.drogariadopovo.treinamento.activity

import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import br.com.guiadeacessibilidade.util.ViewHolder
import com.drogariadopovo.treinamento.R
import com.drogariadopovo.treinamento.activity.BaseActivity
import com.drogariadopovo.treinamento.activity.MainActivity
import com.drogariadopovo.treinamento.activity.duel.DuelActivity
import com.drogariadopovo.treinamento.util.GenericRecyclerAdapter
import kotlinx.android.synthetic.main.fragment_activity_quiz.view.*
import kotlinx.android.synthetic.main.item_quiz.view.*
import org.jetbrains.anko.startActivity

class QuizActivity : BaseActivity() {

    var recycler : RecyclerView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.fragment_activity_quiz)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = getString(R.string.activity)
//        setHasOptionsMenu(true)

        recycler = findViewById(R.id.recycler)
        recycler!!.layoutManager = LinearLayoutManager(this)
    }

    override fun onResume() {
        super.onResume()
        var list = listOf("1","2","3","4")
        setAdapter(list)
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        onBackPressed()
        return super.onOptionsItemSelected(item)
    }

    fun setAdapter(list : List<String>){
        recycler?.adapter = GenericRecyclerAdapter<String, ViewHolder>(this, list, object : GenericRecyclerAdapter.GenericRecyclerViewInterface<String, ViewHolder>{
            override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): ViewHolder {
                return ViewHolder(layoutInflater.inflate(R.layout.item_quiz, parent, false))
            }

            override fun onBindViewHolder(holder: ViewHolder?, position: Int, list: List<String>?) {
                val view = holder!!.itemView
                view.quiz_title.text = "Questionário ${position + 1}"


                if(view.quiz_title.text.contains("4")){
                    view.setOnClickListener {
                        startActivity<DuelActivity>("title" to view.quiz_title.text)
                    }
                }
            }
        })
    }
}
