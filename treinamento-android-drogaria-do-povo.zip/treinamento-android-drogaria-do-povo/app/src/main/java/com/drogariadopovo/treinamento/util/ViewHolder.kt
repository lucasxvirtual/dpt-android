package br.com.guiadeacessibilidade.util

import android.support.v7.widget.RecyclerView
import android.view.View

class ViewHolder(view : View) : RecyclerView.ViewHolder(view)