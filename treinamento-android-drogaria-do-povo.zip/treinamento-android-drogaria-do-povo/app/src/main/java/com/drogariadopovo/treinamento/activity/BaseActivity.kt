package com.drogariadopovo.treinamento.activity

import android.app.Dialog
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.LayoutInflater
import android.view.Window
import com.drogariadopovo.treinamento.R

open class BaseActivity : AppCompatActivity() {

    var dialogTransparent : Dialog? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        dialogTransparent = Dialog(this, android.R.style.Theme_Black )
        val view = LayoutInflater.from(this ).inflate(
                R.layout.progress, null )
        dialogTransparent?.requestWindowFeature( Window.FEATURE_NO_TITLE )
        dialogTransparent?.window?.setBackgroundDrawableResource( R.color.transparent )
        dialogTransparent?.setContentView( view )
    }

    /**
     * show the wait dialog
     */
    fun showDialog( ){
        dialogTransparent?.show( )
    }

    /**
     * hide the wait dialog
     */
    fun hideDialog( ){
        if( dialogTransparent != null &&  dialogTransparent!!.isShowing ){
            dialogTransparent?.dismiss( )
        }
    }

}