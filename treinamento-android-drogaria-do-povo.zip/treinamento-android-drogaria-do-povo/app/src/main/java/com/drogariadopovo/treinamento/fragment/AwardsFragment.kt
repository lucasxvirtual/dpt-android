package com.drogariadopovo.treinamento.fragment

import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.content.ContextCompat
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import br.com.guiadeacessibilidade.util.ViewHolder
import com.drogariadopovo.treinamento.R
import com.drogariadopovo.treinamento.util.GenericRecyclerAdapter
import kotlinx.android.synthetic.main.fragment_awards.*
import kotlinx.android.synthetic.main.fragment_awards.view.*

class AwardsFragment : Fragment() {

    private var recycler : RecyclerView? = null
    private var isPrize = true
    private var list = listOf("1","2","3")

    override fun onResume() {
        super.onResume()
        if(isPrize){
            setAdapterPrizes(list)
            onPrizeClicked()
        } else {
            setAdapterVouchers(list)
            onVoucherClicked()
        }

    }

    fun onPrizeClicked(){
        view?.prize_text?.setTextColor(ContextCompat.getColor(view!!.context,R.color.white))
        view?.prize?.backgroundTintList = ContextCompat.getColorStateList(view!!.context, R.color.blue)

        view?.vouchers_text?.setTextColor(ContextCompat.getColor(view!!.context,R.color.blue))
        view?.vouchers?.backgroundTintList = ContextCompat.getColorStateList(view!!.context, R.color.white)

        isPrize = true
        setAdapterPrizes(list)
    }

    fun onVoucherClicked(){
        view?.prize_text?.setTextColor(ContextCompat.getColor(view!!.context, R.color.blue))
        view?.prize?.backgroundTintList = ContextCompat.getColorStateList(view!!.context, R.color.white)

        view?.vouchers_text?.setTextColor(ContextCompat.getColor(view!!.context, R.color.white))
        view?.vouchers?.backgroundTintList = ContextCompat.getColorStateList(view!!.context, R.color.blue)

        isPrize = false
        setAdapterVouchers(list)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_awards, container, false)

        recycler = view.findViewById(R.id.recycler_prizes_voucher)
        recycler!!.layoutManager = LinearLayoutManager(context)

        view.prize.setOnClickListener {
            onPrizeClicked()
        }

        view.vouchers.setOnClickListener {
            onVoucherClicked()
        }

        return view
    }

    fun setAdapterPrizes(list : List<String>){
        recycler_prizes_voucher?.adapter = GenericRecyclerAdapter<String, ViewHolder>(context, list, object : GenericRecyclerAdapter.GenericRecyclerViewInterface<String, ViewHolder>{
            override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): ViewHolder {
                return ViewHolder(layoutInflater.inflate(R.layout.item_prizes, parent, false))
            }

            override fun onBindViewHolder(holder: ViewHolder?, position: Int, list: List<String>?) {
                val view = holder!!.itemView

            }
        })
    }

    fun setAdapterVouchers(list : List<String>){
        recycler_prizes_voucher?.adapter = GenericRecyclerAdapter<String, ViewHolder>(context, list, object : GenericRecyclerAdapter.GenericRecyclerViewInterface<String, ViewHolder>{
            override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): ViewHolder {
                return ViewHolder(layoutInflater.inflate(R.layout.item_vouchers, parent, false))
            }

            override fun onBindViewHolder(holder: ViewHolder?, position: Int, list: List<String>?) {
                val view = holder!!.itemView

            }
        })
    }
}