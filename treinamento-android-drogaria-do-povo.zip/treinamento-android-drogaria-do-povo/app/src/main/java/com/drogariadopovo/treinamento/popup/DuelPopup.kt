package com.drogariadopovo.treinamento.popup

import android.app.AlertDialog
import android.support.design.widget.TextInputLayout
import android.view.View
import android.widget.Button
import com.drogariadopovo.treinamento.R
import com.drogariadopovo.treinamento.activity.BaseActivity
import kotlinx.android.synthetic.main.popup_profile.view.*
import org.jetbrains.anko.toast

class DuelPopup(val activity: BaseActivity) {

    private var dialog : AlertDialog? = null

    init {
        val builder = AlertDialog.Builder(activity)
        val view =  activity.layoutInflater.inflate(R.layout.popup_duel, null)

        builder.setView( view)
        dialog = builder.create()
        dialog?.show()


    }

}