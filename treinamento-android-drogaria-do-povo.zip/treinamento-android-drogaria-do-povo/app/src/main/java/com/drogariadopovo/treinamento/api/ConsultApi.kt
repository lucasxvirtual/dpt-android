package com.drogariadopovo.treinamento.api

import okhttp3.OkHttpClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*
import java.util.concurrent.TimeUnit

class ConsultApi() : Api() {

    private var retrofit: Retrofit? = null
    var apiService: ConsultApi.ApiService? = null

    constructor(baseUrl: String) : this() {

        val okHttpClient: OkHttpClient = OkHttpClient().newBuilder().readTimeout(60, TimeUnit.SECONDS)
                .writeTimeout(60, TimeUnit.SECONDS)
                .connectTimeout(60, TimeUnit.SECONDS)
                .build()


        retrofit = Retrofit.Builder()
                .client(okHttpClient)
                .baseUrl(baseUrl)
                .addConverterFactory(GsonConverterFactory.create())
                .build()

        this.apiService = retrofit!!.create(ApiService::class.java)

    }

    fun <T> callback(callback: ApiCallback<T>): Callback<T> {
        return object : Callback<T> {
            override fun onResponse(call: Call<T>, response: retrofit2.Response<T>) {
                if (response.code() >= 200 && response.code() <= 300) {
                    callback.onResponse(response.body()!!)
                } else {
                    callback.onFailure(response)
                }
            }

            override fun onFailure(call: Call<T>, t: Throwable) {
                callback.onConnectionFailure(t)
            }
        }
    }

    /* Methods that call ApiService Request should be written below */

    interface ApiService {
        /* Requests are listed here */


    }
}