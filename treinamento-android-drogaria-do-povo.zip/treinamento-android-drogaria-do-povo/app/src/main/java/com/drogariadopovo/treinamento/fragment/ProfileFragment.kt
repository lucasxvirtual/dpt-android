package com.drogariadopovo.treinamento.fragment

import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.drogariadopovo.treinamento.activity.MainActivity
import com.drogariadopovo.treinamento.R
import com.drogariadopovo.treinamento.activity.getintouch.GetInTouchActivity
import com.drogariadopovo.treinamento.popup.DuelPopup
import com.drogariadopovo.treinamento.popup.ProfilePopup
import kotlinx.android.synthetic.main.fragment_profile.view.*
import org.jetbrains.anko.startActivity

class ProfileFragment : Fragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_profile, container, false)


        view.hr_card.setOnClickListener {
            activity!!.startActivity<GetInTouchActivity>()
        }

        view.edit_profile.setOnClickListener {
            ProfilePopup(activity as MainActivity)
        }

        return view
    }
}